import tkinter as tk
from tkinter import messagebox
import os
import random

# Constants
TASKS_FILE = "tasks.txt"
BG_COLOR = "#ffe6f0"
BUTTON_COLOR = "#f9c5d1"
FONT_MAIN = ("Comic Sans MS", 12)
FONT_TITLE = ("Comic Sans MS", 16, "bold")
FONT_QUOTE = ("Comic Sans MS", 10, "italic")
FONT_PRIORITY = ("Comic Sans MS", 10)

QUOTES = [
    "🌼 You got this!",
    "🌈 One task at a time!",
    "🍓 Stay sweet and focused!",
    "☁️ Breathe and do your best!",
    "🌟 Progress, not perfection!"
]

PRIORITY_COLORS = {
    "important": "red",
    "chores": "orange",
    "goal": "green"
}


class CuteToDoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🌸 MyTo-Do List")
        self.root.geometry("440x580")
        self.root.configure(bg=BG_COLOR)
        self.tasks = []

        # Title
        tk.Label(root, text="My To-Do List 🐻", font=FONT_TITLE, bg=BG_COLOR).pack(pady=10)

        # Motivational Quote
        quote = random.choice(QUOTES)
        tk.Label(root, text=quote, font=FONT_QUOTE, bg=BG_COLOR).pack(pady=5)

        # Entry field
        self.task_entry = tk.Entry(root, width=30, font=FONT_MAIN)
        self.task_entry.pack(pady=8)

        # Priority Buttons
        priority_frame = tk.Frame(root, bg=BG_COLOR)
        priority_frame.pack(pady=5)

        tk.Button(priority_frame, text="🔴 Important", font=FONT_PRIORITY, bg="#ff9999",
                  command=lambda: self.add_task("important")).pack(side=tk.LEFT, padx=5)
        tk.Button(priority_frame, text="🟠 Chores", font=FONT_PRIORITY, bg="#ffd699",
                  command=lambda: self.add_task("chores")).pack(side=tk.LEFT, padx=5)
        tk.Button(priority_frame, text="🟢 Goal", font=FONT_PRIORITY, bg="#b3f0b3",
                  command=lambda: self.add_task("goal")).pack(side=tk.LEFT, padx=5)

        # Task frame
        self.task_frame = tk.Frame(root, bg=BG_COLOR)
        self.task_frame.pack(pady=10)

        # Action buttons
        tk.Button(root, text="➕ Add Task ", font=FONT_MAIN, bg=BUTTON_COLOR,
                  command=lambda: self.add_task("goal")).pack(pady=4)
        tk.Button(root, text="❌ Delete  Tasks", font=FONT_MAIN, bg=BUTTON_COLOR,
                  command=self.delete_tasks).pack(pady=4)

        self.load_tasks()

    def add_task(self, priority_key="goal"):
        task_text = self.task_entry.get().strip()
        if not task_text:
            messagebox.showwarning("Input Error", "Task cannot be empty.")
            return

        color = PRIORITY_COLORS.get(priority_key, "black")

        var = tk.IntVar()
        cb = tk.Checkbutton(
            self.task_frame,
            text="⭐ " + task_text,
            variable=var,
            onvalue=1,
            offvalue=0,
            anchor="w",
            width=35,
            font=FONT_MAIN,
            bg=BG_COLOR,
            fg=color,
            selectcolor=BG_COLOR,
            activebackground=BG_COLOR
        )
        cb.var = var
        cb.priority = priority_key
        cb.pack(anchor="w")
        self.tasks.append(cb)
        self.task_entry.delete(0, tk.END)
        self.save_tasks()
        self.check_all_done()

    def delete_tasks(self):
        to_delete = [cb for cb in self.tasks if cb.var.get() == 1]
        for cb in to_delete:
            cb.destroy()
            self.tasks.remove(cb)
        self.save_tasks()

    def save_tasks(self):
        with open(TASKS_FILE, "w") as f:
            for cb in self.tasks:
                status = cb.var.get()
                text = cb.cget("text").replace("⭐ ", "", 1)
                priority = cb.priority
                f.write(f"{status}|{text}|{priority}\n")

    def load_tasks(self):
        if not os.path.exists(TASKS_FILE):
            return
        with open(TASKS_FILE, "r") as f:
            for line in f:
                try:
                    status, text, priority = line.strip().split("|")
                    var = tk.IntVar(value=int(status))
                    cb = tk.Checkbutton(
                        self.task_frame,
                        text="⭐ " + text,
                        variable=var,
                        onvalue=1,
                        offvalue=0,
                        anchor="w",
                        width=35,
                        font=FONT_MAIN,
                        bg=BG_COLOR,
                        fg=PRIORITY_COLORS.get(priority.lower(), "black"),
                        selectcolor=BG_COLOR,
                        activebackground=BG_COLOR
                    )
                    cb.var = var
                    cb.priority = priority
                    cb.pack(anchor="w")
                    self.tasks.append(cb)
                except ValueError:
                    continue

    def check_all_done(self):
        if self.tasks and all(cb.var.get() == 1 for cb in self.tasks):
            messagebox.showinfo("Yay!", "🎉 All tasks completed! You're amazing!")


# Run the app
if __name__ == "__main__":
    root = tk.Tk()
    app = CuteToDoApp(root)
    root.mainloop()
